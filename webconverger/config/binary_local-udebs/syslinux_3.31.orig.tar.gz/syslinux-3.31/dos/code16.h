/* Must be included first of all */
__asm__ (".code16gcc");

#ifndef _MATH_H
#define _MATH_H

double pow(double, double);
double fabs(double);
double strtod(const char *, char **);

#endif /* _MATH_H */

#define TYPE uint16_t
#define BWL(x) x ## w
#define BIOSCALL 0xb109
#include "pci/readx.c"

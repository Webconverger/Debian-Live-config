#define TYPE long long
#define NAME atoll
#include "atox.c"

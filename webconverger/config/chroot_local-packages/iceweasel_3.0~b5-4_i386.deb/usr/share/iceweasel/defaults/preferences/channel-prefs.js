//@line 2 "/build/buildd/iceweasel-3.0~b5/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");

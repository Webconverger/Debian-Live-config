pref("general.useragent.extra.firefoxComment","(Debian-3.0~b5-4)");

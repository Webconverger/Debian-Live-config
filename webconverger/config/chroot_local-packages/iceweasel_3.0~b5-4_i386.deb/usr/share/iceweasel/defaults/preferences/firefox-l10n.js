//@line 36 "/build/buildd/iceweasel-3.0~b5/browser/locales/en-US/firefox-l10n.js"

//@line 38 "/build/buildd/iceweasel-3.0~b5/browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
